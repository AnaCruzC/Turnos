package com.test.springboot.api.app.models.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.test.springboot.api.app.models.entity.Turnos;


public interface ITurnoDao extends CrudRepository<Turnos, Integer> {
	
	@Query(nativeQuery = true, value = "SELECT TEST.FUNC_GENERAR_TURNOS(:SERVICIO,:FEC_INICIO,:FEC_FIN)")
	public List<Turnos> createTurno(@Param("SERVICIO") int service,
			@Param("FEC_INICIO") Date inicio, @Param("FEC_FIN") Date fin);
}
