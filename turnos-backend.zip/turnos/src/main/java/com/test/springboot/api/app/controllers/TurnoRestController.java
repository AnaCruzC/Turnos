package com.test.springboot.api.app.controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.test.springboot.api.app.models.entity.Turnos;
import com.test.springboot.api.app.models.services.ITurnoService;

@RestController
@RequestMapping("/rest")
public class TurnoRestController {
	
	@Autowired
	@Qualifier("TurnoImpl")
	private ITurnoService turnoService;
	
	@GetMapping("/turnos")
	public List<Turnos> index(){
		List<Turnos> lista= new ArrayList<Turnos>();
		lista = turnoService.findAll();
		return lista;
	}

	@GetMapping("/crearturnos/{id_service}/{fecha_inicio}/{fecha_fin}")
	public List<Turnos> createTurnos(
			@PathVariable("id_service") int id_service,
			@PathVariable("fecha_inicio") @DateTimeFormat(pattern="yyyy-MM-dd") Date fecha_inicio,
			@PathVariable("fecha_fin") @DateTimeFormat(pattern="yyyy-MM-dd") Date fecha_fin
			){
		List<Turnos> listaTurnos= new ArrayList<Turnos>();
		listaTurnos= turnoService.create(1, fecha_inicio, fecha_fin);
		return listaTurnos;
	}
	
	
		
}
