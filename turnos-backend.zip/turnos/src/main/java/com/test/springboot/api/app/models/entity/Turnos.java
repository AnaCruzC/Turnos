package com.test.springboot.api.app.models.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name="TURNOS",schema="TEST")
@NamedStoredProcedureQuery(name = "PROC_GENERAR_TURNOS", 
procedureName = "TEST.PROC_GENERAR_TURNOS",
resultClasses = Turnos.class,
parameters = {
		//@StoredProcedureParameter(mode = ParameterMode.REF_CURSOR, name = "v_ref", type = void.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "SERVICIO", type = Integer.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "FEC_INICIO", type = Date.class),
		@StoredProcedureParameter(mode = ParameterMode.IN, name = "FEC_FIN", type = Date.class),
		//@StoredProcedureParameter(mode = ParameterMode.OUT, name = "v_ref", type = Turnos.class )
		@StoredProcedureParameter(mode = ParameterMode.REF_CURSOR, name = "v_ref", type = Void.class)
})
public class Turnos implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	@Column(name="ID_TURNO")
	private int idTurno;
	
	//@Column(name="ID_SERVICIO")
	private int idServicio;
	
	//@Column(name="FECHA_TURNO")
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
	private Date fechaTurno;
	
	//@Column(name="HORA_INICIO")
	@DateTimeFormat(pattern = "yyyy-MM-dd hh:mm:ss")
	private Date horaInicio;
	
	//@Column(name="HORA_FIN")
	private Date horaFin;
	
	//@Column(name="ESTADO")
	private String estado;
	
	public int getIdTurno() {
		return idTurno;
	}

	public void setIdTurno(int idTurno) {
		this.idTurno = idTurno;
	}

	public int getIdServicio() {
		return idServicio;
	}

	public void setIdServicio(int idServicio) {
		this.idServicio = idServicio;
	}

	public Date getFechaTurno() {
		return fechaTurno;
	}

	public void setFechaTurno(Date fechaTurno) {
		this.fechaTurno = fechaTurno;
	}

	public Date getHoraInicio() {
		return horaInicio;
	}

	public void setHoraInicio(Date horaInicio) {
		this.horaInicio = horaInicio;
	}

	public Date getHoraFin() {
		return horaFin;
	}

	public void setHoraFin(Date horaFin) {
		this.horaFin = horaFin;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
}
