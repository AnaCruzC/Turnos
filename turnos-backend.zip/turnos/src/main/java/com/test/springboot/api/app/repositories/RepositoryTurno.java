package com.test.springboot.api.app.repositories;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.test.springboot.api.app.models.entity.Turnos;

@Repository("RepositoryTurno")
public interface RepositoryTurno extends CrudRepository<Turnos, Integer> {

	 @Procedure(name = "PROC_GENERAR_TURNOS")
	 public List<Turnos> createTurnos(@Param("SERVICIO") int service,
				@Param("FEC_INICIO") Date inicio, @Param("FEC_FIN") Date fin);

	
}
