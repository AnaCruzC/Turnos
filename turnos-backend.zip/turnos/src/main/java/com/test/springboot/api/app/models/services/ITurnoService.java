package com.test.springboot.api.app.models.services;

import java.util.Date;
import java.util.List;

import com.test.springboot.api.app.models.entity.Turnos;

public interface ITurnoService {
	
	public List<Turnos> findAll();
	
	public Turnos save(Turnos turno);
	
	public List<Turnos> create(int service, Date inicio, Date fin);

}
