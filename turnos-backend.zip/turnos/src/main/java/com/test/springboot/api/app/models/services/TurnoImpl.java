package com.test.springboot.api.app.models.services;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.test.springboot.api.app.models.entity.Turnos;
import com.test.springboot.api.app.repositories.RepositoryTurno;

@Service("TurnoImpl")
@Transactional
public class TurnoImpl implements ITurnoService{

	@Autowired
	@Qualifier("RepositoryTurno")
	private RepositoryTurno repositoryTurno;
	
	@Override
	public List<Turnos> findAll() {
		// TODO Auto-generated method stub
		return (List<Turnos>)repositoryTurno.findAll();
	}

	@Override
	public Turnos save(Turnos turno) {
		// TODO Auto-generated method stub
		return repositoryTurno.save(turno);
	}

	@Override
	public List<Turnos> create(int service, Date inicio, Date fin) {
		// TODO Auto-generated method stub
		return repositoryTurno.createTurnos(service, inicio, fin);
	}

	

}
