export interface turno{
    id_turno:number ;
    id_servicio:number;
    fecha_turno :Date;
    hora_inicio:Date;
    hora_fin:Date;    
    estado:string;
}