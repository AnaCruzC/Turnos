import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  usuarioLogin: string = "";
  contrasena: string = "";

  constructor(private router: Router) { }

  ngOnInit(): void {
  }

  validarLogin (){
    // validate:Boolean=false;
    console.log(this.usuarioLogin+''+this.contrasena);
    if (this.usuarioLogin=="Usua1" && this.contrasena=="123456") {
      console.log('-------------------');
      this.router.navigate(['/turnos']);
      
    }
     
  }

}
