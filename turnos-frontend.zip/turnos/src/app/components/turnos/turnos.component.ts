import { Component, OnInit } from '@angular/core';
import { turno } from '../../models/turno.model';
import { TurnosServicioService } from 'src/app/services/turnos-servicio.service';

@Component({
  selector: 'app-turnos',
  templateUrl: './turnos.component.html',
  styleUrls: ['./turnos.component.css']
})
export class TurnosComponent implements OnInit {

  lista_turnos: turno[] = [];
  constructor(private turnosServicioService : TurnosServicioService) { }

  ngOnInit(): void {
    this.turnosServicioService.getAllShifts()
    .subscribe(data =>{
      console.log(data);
      this.lista_turnos = data;
    })
  }

}
