import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { turno } from '../models/turno.model';
import { HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TurnosServicioService {

  constructor(private http: HttpClient) { }

  getAllShifts(){
    const headers = new HttpHeaders()
      .append('Content-Type', 'application/json')
      .append('Access-Control-Allow-Headers', 'Content-Type')
      .append('Access-Control-Allow-Methods', 'GET')
      .append('Access-Control-Allow-Origin', '*');
    return this.http.get<turno[]>('http://localhost:5000/rest/turnos',{headers});

  }

  getGenerateShifts(){
    return this.http.get<turno[]>('api/rest/crearturnos/1/2022-07-14/2022-07-15');
  }
}
