import { TestBed } from '@angular/core/testing';

import { TurnosServicioService } from './turnos-servicio.service';

describe('TurnosServicioService', () => {
  let service: TurnosServicioService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TurnosServicioService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
